# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'httag'
#

CREATE TABLE httag (
  httag_id int(11) NOT NULL auto_increment,
  variation_group_id int(11) DEFAULT '0' NOT NULL,
  name varchar(255),
  source_id int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (httag_id),
  KEY variation_group_idx (variation_group_id)
);
