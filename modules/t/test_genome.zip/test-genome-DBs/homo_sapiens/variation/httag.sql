# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'httag'
#

DROP TABLE IF EXISTS httag;
CREATE TABLE httag (
  httag_id int(11) NOT NULL auto_increment,
  variation_group_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  source_id int(11) NOT NULL default '0',
  PRIMARY KEY  (httag_id),
  KEY variation_group_idx (variation_group_id)
) TYPE=MyISAM;
