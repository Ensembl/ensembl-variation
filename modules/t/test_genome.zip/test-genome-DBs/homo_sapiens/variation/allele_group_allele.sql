# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'allele_group_allele'
#

CREATE TABLE allele_group_allele (
  allele_group_id int(11) NOT NULL default '0',
  allele varchar(255) NOT NULL default '',
  variation_id int(11) NOT NULL default '0',
  UNIQUE KEY allele_group_id (allele_group_id,variation_id),
  KEY allele_idx (variation_id,allele_group_id)
) TYPE=MyISAM;
