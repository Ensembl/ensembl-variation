# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'allele_group_allele'
#

CREATE TABLE allele_group_allele (
  allele_group_id int(11) DEFAULT '0' NOT NULL,
  allele varchar(255) DEFAULT '' NOT NULL,
  variation_id int(11) DEFAULT '0' NOT NULL,
  UNIQUE allele_group_id (allele_group_id,variation_id),
  KEY allele_idx (variation_id,allele_group_id)
);
