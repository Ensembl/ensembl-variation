# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'individual_population'
#

CREATE TABLE individual_population (
  individual_id int(11) NOT NULL default '0',
  population_id int(11) NOT NULL default '0',
  KEY individual_idx (individual_id),
  KEY population_idx (population_id)
) TYPE=MyISAM;
