# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'population_synonym'
#

DROP TABLE IF EXISTS population_synonym;
CREATE TABLE population_synonym (
  population_synonym_id int(11) NOT NULL auto_increment,
  population_id int(11) NOT NULL default '0',
  source_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  PRIMARY KEY  (population_synonym_id),
  UNIQUE KEY name (name,source_id),
  KEY population_idx (population_id)
) TYPE=MyISAM;
