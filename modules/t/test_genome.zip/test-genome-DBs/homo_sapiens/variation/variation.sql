# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'variation'
#

DROP TABLE IF EXISTS variation;
CREATE TABLE variation (
  variation_id int(11) NOT NULL auto_increment,
  source_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  validation_status set('cluster','freq','submitter','doublehit','hapmap') default NULL,
  PRIMARY KEY  (variation_id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;
