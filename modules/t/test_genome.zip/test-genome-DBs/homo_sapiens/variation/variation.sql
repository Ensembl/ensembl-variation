# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'variation'
#

CREATE TABLE variation (
  variation_id int(11) NOT NULL auto_increment,
  source_id int(11) DEFAULT '0' NOT NULL,
  name varchar(255),
  validation_status set('cluster','freq','submitter','doublehit','hapmap'),
  PRIMARY KEY (variation_id),
  UNIQUE name (name)
);
