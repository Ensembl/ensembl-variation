# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'variation'
#

CREATE TABLE variation (
  variation_id int(11) NOT NULL auto_increment,
  source_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  validation_status set('cluster','freq','submitter','doublehit','hapmap') default NULL,
  PRIMARY KEY  (variation_id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;
