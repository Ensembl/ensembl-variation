# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'pairwise_ld'
#

CREATE TABLE pairwise_ld (
  variation_feature_id_1 int(11) NOT NULL default '0',
  variation_feature_id_2 int(11) NOT NULL default '0',
  population_id int(11) NOT NULL default '0',
  seq_region_id int(11) NOT NULL default '0',
  seq_region_start int(11) NOT NULL default '0',
  seq_region_end int(11) NOT NULL default '0',
  r2 float NOT NULL default '0',
  d_prime float NOT NULL default '0',
  sample_count int(11) NOT NULL default '0',
  KEY seq_region_1_idx (seq_region_id)
) TYPE=MyISAM;
