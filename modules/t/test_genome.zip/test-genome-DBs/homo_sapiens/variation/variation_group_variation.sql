# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'variation_group_variation'
#

CREATE TABLE variation_group_variation (
  variation_id int(11) NOT NULL default '0',
  variation_group_id int(11) NOT NULL default '0',
  UNIQUE KEY variation_group_id (variation_group_id,variation_id),
  KEY variation_idx (variation_id,variation_group_id)
) TYPE=MyISAM;
