# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'variation_group_variation'
#

CREATE TABLE variation_group_variation (
  variation_id int(11) DEFAULT '0' NOT NULL,
  variation_group_id int(11) DEFAULT '0' NOT NULL,
  UNIQUE variation_group_id (variation_group_id,variation_id),
  KEY variation_idx (variation_id,variation_group_id)
);
