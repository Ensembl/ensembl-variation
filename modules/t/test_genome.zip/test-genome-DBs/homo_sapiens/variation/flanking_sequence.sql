# MySQL dump 8.16
#
# Host: ecs4    Database: mcvicker_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'flanking_sequence'
#

CREATE TABLE flanking_sequence (
  variation_id int(11) NOT NULL default '0',
  up_seq text,
  down_seq text,
  up_seq_region_start int(11) default NULL,
  up_seq_region_end int(11) default NULL,
  down_seq_region_start int(11) default NULL,
  down_seq_region_end int(11) default NULL,
  seq_region_id int(11) default NULL,
  seq_region_strand tinyint(4) default NULL,
  PRIMARY KEY  (variation_id)
) TYPE=MyISAM MAX_ROWS=100000000;
