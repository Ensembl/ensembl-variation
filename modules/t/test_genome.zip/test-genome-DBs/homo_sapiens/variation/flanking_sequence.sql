# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'flanking_sequence'
#

CREATE TABLE flanking_sequence (
  variation_id int(11) DEFAULT '0' NOT NULL,
  up_seq text,
  down_seq text,
  up_seq_region_start int(11),
  up_seq_region_end int(11),
  down_seq_region_start int(11),
  down_seq_region_end int(11),
  seq_region_id int(11),
  seq_region_strand tinyint(4),
  PRIMARY KEY (variation_id)
);
