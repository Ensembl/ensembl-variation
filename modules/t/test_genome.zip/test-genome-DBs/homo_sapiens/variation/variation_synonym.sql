# MySQL dump 8.16
#
# Host: ecs4    Database: mcvicker_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'variation_synonym'
#

CREATE TABLE variation_synonym (
  variation_synonym_id int(11) NOT NULL auto_increment,
  variation_id int(11) NOT NULL default '0',
  source_id int(11) NOT NULL default '0',
  name varchar(255) default NULL,
  PRIMARY KEY  (variation_synonym_id),
  UNIQUE KEY name (name,source_id),
  KEY variation_idx (variation_id)
) TYPE=MyISAM;
