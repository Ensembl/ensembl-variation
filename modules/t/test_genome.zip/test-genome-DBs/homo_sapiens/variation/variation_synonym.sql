# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'variation_synonym'
#

CREATE TABLE variation_synonym (
  variation_synonym_id int(11) NOT NULL auto_increment,
  variation_id int(11) DEFAULT '0' NOT NULL,
  source_id int(11) DEFAULT '0' NOT NULL,
  name varchar(255),
  PRIMARY KEY (variation_synonym_id),
  UNIQUE name (name,source_id),
  KEY variation_idx (variation_id)
);
