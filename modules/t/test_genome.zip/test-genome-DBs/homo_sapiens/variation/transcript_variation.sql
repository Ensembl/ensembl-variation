# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'transcript_variation'
#

CREATE TABLE transcript_variation (
  transcript_variation_id int(11) NOT NULL auto_increment,
  transcript_id int(11) DEFAULT '0' NOT NULL,
  variation_feature_id int(11) DEFAULT '0' NOT NULL,
  cdna_start int(11),
  cdna_end int(11),
  translation_start int(11),
  translation_end int(11),
  peptide_allele_string varchar(255),
  type enum('INTRONIC','UPSTREAM','DOWNSTREAM','SYNONYMOUS_CODING','NON_SYNONYMOUS_CODING','FRAMESHIFT_CODING','5PRIME_UTR','3PRIME_UTR') DEFAULT 'INTRONIC' NOT NULL,
  PRIMARY KEY (transcript_variation_id),
  KEY variation_idx (variation_feature_id),
  KEY transcript_idx (transcript_id),
  KEY type_idx (type)
);
