# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'individual_genotype_single_bp'
#

CREATE TABLE individual_genotype_single_bp (
  variation_id int(11) NOT NULL default '0',
  allele_1 char(1) NOT NULL default '',
  allele_2 char(1) NOT NULL default '',
  individual_id int(11) default NULL
) TYPE=MyISAM;
