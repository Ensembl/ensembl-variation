# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'allele_group'
#

CREATE TABLE allele_group (
  allele_group_id int(11) NOT NULL auto_increment,
  variation_group_id int(11) NOT NULL default '0',
  population_id int(11) default NULL,
  name varchar(255) default NULL,
  source_id int(11) default NULL,
  frequency float default NULL,
  PRIMARY KEY  (allele_group_id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;
