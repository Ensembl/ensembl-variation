# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'allele_group'
#

CREATE TABLE allele_group (
  allele_group_id int(11) NOT NULL auto_increment,
  variation_group_id int(11) DEFAULT '0' NOT NULL,
  population_id int(11),
  name varchar(255),
  source_id int(11),
  frequency float,
  PRIMARY KEY (allele_group_id),
  UNIQUE name (name)
);
