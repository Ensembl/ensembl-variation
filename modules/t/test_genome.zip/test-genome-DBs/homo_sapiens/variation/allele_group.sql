# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'allele_group'
#

CREATE TABLE allele_group (
  allele_group_id int(11) NOT NULL auto_increment,
  variation_group_id int(11) NOT NULL default '0',
  population_id int(11) default NULL,
  name varchar(255) default NULL,
  source_id int(11) default NULL,
  frequency float default NULL,
  PRIMARY KEY  (allele_group_id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;
