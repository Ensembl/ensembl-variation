# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'variation_feature'
#

CREATE TABLE variation_feature (
  variation_feature_id int(11) NOT NULL auto_increment,
  seq_region_id int(11) NOT NULL default '0',
  seq_region_start int(11) NOT NULL default '0',
  seq_region_end int(11) NOT NULL default '0',
  seq_region_strand tinyint(4) NOT NULL default '0',
  variation_id int(11) NOT NULL default '0',
  allele_string text,
  variation_name varchar(255) default NULL,
  map_weight int(11) NOT NULL default '0',
  flags set('genotyped') default NULL,
  PRIMARY KEY  (variation_feature_id),
  KEY pos_idx (seq_region_id,seq_region_start),
  KEY variation_idx (variation_id)
) TYPE=MyISAM;
