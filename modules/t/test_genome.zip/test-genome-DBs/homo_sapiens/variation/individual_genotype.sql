# MySQL dump 8.16
#
# Host: ecs4    Database: mcvicker_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'individual_genotype'
#

CREATE TABLE individual_genotype (
  individual_genotype_id int(11) NOT NULL auto_increment,
  variation_id int(11) NOT NULL default '0',
  allele_1 varchar(255) default NULL,
  allele_2 varchar(255) default NULL,
  individual_id int(11) default NULL,
  PRIMARY KEY  (individual_genotype_id),
  KEY variation_idx (variation_id),
  KEY individual_idx (individual_id)
) TYPE=MyISAM;
