# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'population_structure'
#

CREATE TABLE population_structure (
  super_population_id int(11) DEFAULT '0' NOT NULL,
  sub_population_id int(11) DEFAULT '0' NOT NULL,
  UNIQUE super_population_id (super_population_id,sub_population_id),
  KEY sub_pop_idx (sub_population_id,super_population_id)
);
