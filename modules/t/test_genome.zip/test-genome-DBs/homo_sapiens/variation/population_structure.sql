# MySQL dump 8.16
#
# Host: ecs4    Database: mcvicker_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'population_structure'
#

CREATE TABLE population_structure (
  super_population_id int(11) NOT NULL default '0',
  sub_population_id int(11) NOT NULL default '0',
  UNIQUE KEY super_population_id (super_population_id,sub_population_id),
  KEY sub_pop_idx (sub_population_id,super_population_id)
) TYPE=MyISAM;
