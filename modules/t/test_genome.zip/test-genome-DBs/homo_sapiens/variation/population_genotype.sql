# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'population_genotype'
#

DROP TABLE IF EXISTS population_genotype;
CREATE TABLE population_genotype (
  population_genotype_id int(11) NOT NULL auto_increment,
  variation_id int(11) NOT NULL default '0',
  allele_1 varchar(255) default NULL,
  allele_2 varchar(255) default NULL,
  frequency float default NULL,
  population_id int(11) default NULL,
  PRIMARY KEY  (population_genotype_id),
  KEY variation_idx (variation_id),
  KEY population_idx (population_id)
) TYPE=MyISAM;
