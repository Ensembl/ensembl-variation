# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'variation_group'
#

DROP TABLE IF EXISTS variation_group;
CREATE TABLE variation_group (
  variation_group_id int(11) NOT NULL auto_increment,
  name varchar(255) default NULL,
  source_id int(11) NOT NULL default '0',
  type enum('haplotype','tag') default NULL,
  PRIMARY KEY  (variation_group_id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;
