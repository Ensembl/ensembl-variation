# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'variation_group'
#

CREATE TABLE variation_group (
  variation_group_id int(11) NOT NULL auto_increment,
  name varchar(255),
  source_id int(11) DEFAULT '0' NOT NULL,
  type enum('haplotype','tag'),
  PRIMARY KEY (variation_group_id),
  UNIQUE name (name)
);
