# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'allele'
#

CREATE TABLE allele (
  allele_id int(11) NOT NULL auto_increment,
  variation_id int(11) DEFAULT '0' NOT NULL,
  allele text,
  frequency float,
  population_id int(11),
  PRIMARY KEY (allele_id),
  KEY variation_idx (variation_id),
  KEY allele_idx (allele_id)
);
