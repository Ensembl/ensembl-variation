# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'allele'
#

CREATE TABLE allele (
  allele_id int(11) NOT NULL auto_increment,
  variation_id int(11) NOT NULL default '0',
  allele text,
  frequency float default NULL,
  population_id int(11) default NULL,
  PRIMARY KEY  (allele_id),
  KEY variation_idx (variation_id),
  KEY allele_idx (allele_id)
) TYPE=MyISAM;
