# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'individual'
#

DROP TABLE IF EXISTS individual;
CREATE TABLE individual (
  individual_id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  population_id int(11) NOT NULL default '0',
  gender enum('Male','Female','Unknown') NOT NULL default 'Unknown',
  father_individual_id int(11) default NULL,
  mother_individual_id int(11) default NULL,
  PRIMARY KEY  (individual_id),
  KEY population_idx (population_id),
  KEY name_idx (name)
) TYPE=MyISAM;
