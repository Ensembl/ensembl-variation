# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'individual'
#

CREATE TABLE individual (
  individual_id int(11) NOT NULL auto_increment,
  name varchar(255) DEFAULT '' NOT NULL,
  description varchar(255) DEFAULT '' NOT NULL,
  population_id int(11) DEFAULT '0' NOT NULL,
  gender enum('Male','Female','Unknown') DEFAULT 'Unknown' NOT NULL,
  father_individual_id int(11),
  mother_individual_id int(11),
  PRIMARY KEY (individual_id),
  KEY population_idx (population_id),
  KEY name_idx (name)
);
