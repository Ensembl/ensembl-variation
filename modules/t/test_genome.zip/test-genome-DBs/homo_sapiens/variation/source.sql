# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'source'
#

CREATE TABLE source (
  source_id int(11) NOT NULL auto_increment,
  name varchar(255) default NULL,
  PRIMARY KEY  (source_id)
) TYPE=MyISAM;
