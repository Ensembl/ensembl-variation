# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'source'
#

CREATE TABLE source (
  source_id int(11) NOT NULL auto_increment,
  name varchar(255),
  PRIMARY KEY (source_id)
);
