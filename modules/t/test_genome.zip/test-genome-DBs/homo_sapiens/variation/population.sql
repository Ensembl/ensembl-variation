# MySQL dump 8.16
#
# Host: ecs2    Database: _test_db_homo_sapiens_variation_dr2_10_1_162516
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'population'
#

CREATE TABLE population (
  population_id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  size int(11) default NULL,
  description text,
  is_strain int(1) NOT NULL default '0',
  PRIMARY KEY  (population_id),
  KEY name_idx (name)
) TYPE=MyISAM;
