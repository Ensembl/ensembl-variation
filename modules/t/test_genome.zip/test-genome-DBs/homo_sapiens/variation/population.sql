# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'population'
#

CREATE TABLE population (
  population_id int(11) NOT NULL auto_increment,
  name varchar(255) DEFAULT '' NOT NULL,
  size int(11),
  description text,
  PRIMARY KEY (population_id),
  KEY name_idx (name)
);
