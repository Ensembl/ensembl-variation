# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_variation
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'meta_coord'
#

DROP TABLE IF EXISTS meta_coord;
CREATE TABLE meta_coord (
  table_name varchar(40) default NULL,
  coord_system_id int(11) default NULL,
  max_length int(11) default NULL
) TYPE=MyISAM;
