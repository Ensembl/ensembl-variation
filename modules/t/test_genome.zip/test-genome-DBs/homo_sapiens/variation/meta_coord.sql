# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_variation
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'meta_coord'
#

CREATE TABLE meta_coord (
  table_name varchar(40),
  coord_system_id int(11)
);
