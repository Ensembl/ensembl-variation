# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'misc_feature_misc_set'
#

CREATE TABLE misc_feature_misc_set (
  misc_feature_id int(10) unsigned NOT NULL default '0',
  misc_set_id smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (misc_feature_id,misc_set_id),
  KEY reverse_idx (misc_set_id,misc_feature_id)
) TYPE=MyISAM;
