# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'assembly_exception'
#

DROP TABLE IF EXISTS assembly_exception;
CREATE TABLE assembly_exception (
  assembly_exception_id int(11) default NULL,
  seq_region_id int(11) default NULL,
  seq_region_start int(11) default NULL,
  seq_region_end int(11) default NULL,
  exc_type enum('HAP','PAR') default NULL,
  exc_seq_region_id int(11) default NULL,
  exc_seq_region_start int(11) default NULL,
  exc_seq_region_end int(11) default NULL,
  ori int(11) default NULL,
  KEY sr_idx (seq_region_id,seq_region_start),
  KEY ex_idx (exc_seq_region_id,exc_seq_region_start)
) TYPE=MyISAM;
