# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'dna'
#

DROP TABLE IF EXISTS dna;
CREATE TABLE dna (
  seq_region_id int(10) unsigned NOT NULL default '0',
  sequence mediumtext NOT NULL,
  PRIMARY KEY  (seq_region_id)
) TYPE=MyISAM;
