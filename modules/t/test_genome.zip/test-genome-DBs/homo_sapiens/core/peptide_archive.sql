# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'peptide_archive'
#

DROP TABLE IF EXISTS peptide_archive;
CREATE TABLE peptide_archive (
  translation_stable_id varchar(40) NOT NULL default '',
  translation_version smallint(6) NOT NULL default '0',
  peptide_seq mediumtext NOT NULL,
  PRIMARY KEY  (translation_stable_id,translation_version)
) TYPE=MyISAM;
