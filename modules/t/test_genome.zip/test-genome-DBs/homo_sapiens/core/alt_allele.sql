# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'alt_allele'
#

DROP TABLE IF EXISTS alt_allele;
CREATE TABLE alt_allele (
  alt_allele_id int(11) NOT NULL auto_increment,
  gene_id int(11) NOT NULL default '0',
  UNIQUE KEY gene_idx (gene_id),
  UNIQUE KEY allele_idx (alt_allele_id,gene_id)
) TYPE=MyISAM;
