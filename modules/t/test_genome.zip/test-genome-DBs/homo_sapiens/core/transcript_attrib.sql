# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'transcript_attrib'
#

DROP TABLE IF EXISTS transcript_attrib;
CREATE TABLE transcript_attrib (
  transcript_id int(10) unsigned NOT NULL default '0',
  attrib_type_id smallint(5) unsigned NOT NULL default '0',
  value varchar(255) NOT NULL default '',
  KEY type_val_idx (attrib_type_id,value),
  KEY transcript_idx (transcript_id)
) TYPE=MyISAM;
