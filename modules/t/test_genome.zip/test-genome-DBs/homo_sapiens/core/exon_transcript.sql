# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'exon_transcript'
#

DROP TABLE IF EXISTS exon_transcript;
CREATE TABLE exon_transcript (
  exon_id int(10) unsigned NOT NULL default '0',
  transcript_id int(10) unsigned NOT NULL default '0',
  rank int(10) NOT NULL default '0',
  PRIMARY KEY  (exon_id,transcript_id,rank),
  KEY transcript (transcript_id),
  KEY exon (exon_id)
) TYPE=MyISAM;
