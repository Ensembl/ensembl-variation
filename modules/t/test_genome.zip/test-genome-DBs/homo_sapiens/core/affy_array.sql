# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'affy_array'
#

DROP TABLE IF EXISTS affy_array;
CREATE TABLE affy_array (
  affy_array_id int(11) NOT NULL auto_increment,
  parent_array_id int(11) default NULL,
  probe_setsize tinyint(4) NOT NULL default '0',
  name varchar(40) NOT NULL default '',
  PRIMARY KEY  (affy_array_id)
) TYPE=MyISAM;
