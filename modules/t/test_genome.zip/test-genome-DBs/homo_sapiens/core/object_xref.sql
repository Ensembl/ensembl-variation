# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'object_xref'
#

CREATE TABLE object_xref (
  object_xref_id int(11) NOT NULL auto_increment,
  ensembl_id int(10) unsigned NOT NULL default '0',
  ensembl_object_type enum('RawContig','Transcript','Gene','Translation') NOT NULL default 'RawContig',
  xref_id int(10) unsigned NOT NULL default '0',
  UNIQUE KEY ensembl_object_type (ensembl_object_type,ensembl_id,xref_id),
  KEY xref_index (object_xref_id,xref_id,ensembl_object_type,ensembl_id)
) TYPE=MyISAM;
