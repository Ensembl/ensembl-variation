# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'gene_description'
#

CREATE TABLE gene_description (
  gene_id int(10) unsigned NOT NULL default '0',
  description text,
  PRIMARY KEY  (gene_id)
) TYPE=MyISAM;
