# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'external_synonym'
#

DROP TABLE IF EXISTS external_synonym;
CREATE TABLE external_synonym (
  xref_id int(10) unsigned NOT NULL default '0',
  synonym varchar(40) NOT NULL default '',
  PRIMARY KEY  (xref_id,synonym),
  KEY name_index (synonym)
) TYPE=MyISAM;
