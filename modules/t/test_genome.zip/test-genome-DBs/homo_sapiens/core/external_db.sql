# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'external_db'
#

CREATE TABLE external_db (
  external_db_id int(11) NOT NULL default '0',
  db_name varchar(100) NOT NULL default '',
  release varchar(40) NOT NULL default '',
  status enum('KNOWNXREF','KNOWN','XREF','PRED','ORTH','PSEUDO') NOT NULL default 'KNOWNXREF',
  PRIMARY KEY  (external_db_id)
) TYPE=MyISAM;
