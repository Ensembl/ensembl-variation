# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'seq_region_attrib'
#

CREATE TABLE seq_region_attrib (
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  attrib_type_id smallint(5) unsigned DEFAULT '0' NOT NULL,
  value varchar(255) DEFAULT '' NOT NULL,
  KEY type_val_idx (attrib_type_id,value),
  KEY seq_region_idx (seq_region_id)
);
