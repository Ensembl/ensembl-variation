# MySQL dump 8.10
#
# Host: localhost    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'density_type'
#

CREATE TABLE density_type (
  density_type_id int(11) NOT NULL auto_increment,
  analysis_id int(11) DEFAULT '0' NOT NULL,
  block_size int(11) DEFAULT '0' NOT NULL,
  value_type enum('sum','ratio') NOT NULL,
  PRIMARY KEY (density_type_id),
  UNIQUE analysis_idx (analysis_id,block_size)
);
