# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'density_type'
#

CREATE TABLE density_type (
  density_type_id int(11) NOT NULL auto_increment,
  analysis_id int(11) NOT NULL default '0',
  block_size int(11) NOT NULL default '0',
  value_type enum('sum','ratio') NOT NULL default 'sum',
  PRIMARY KEY  (density_type_id),
  UNIQUE KEY analysis_idx (analysis_id,block_size)
) TYPE=MyISAM;
