# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'gene_archive'
#

DROP TABLE IF EXISTS gene_archive;
CREATE TABLE gene_archive (
  gene_stable_id varchar(40) NOT NULL default '',
  gene_version smallint(6) NOT NULL default '0',
  transcript_stable_id varchar(40) NOT NULL default '',
  transcript_version smallint(6) NOT NULL default '0',
  translation_stable_id varchar(40) NOT NULL default '',
  translation_version smallint(6) NOT NULL default '0',
  mapping_session_id int(11) NOT NULL default '0',
  KEY gene_idx (gene_stable_id,gene_version),
  KEY transcript_idx (transcript_stable_id,transcript_version)
) TYPE=MyISAM;
