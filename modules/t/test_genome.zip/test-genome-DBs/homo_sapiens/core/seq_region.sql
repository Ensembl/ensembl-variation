# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'seq_region'
#

CREATE TABLE seq_region (
  seq_region_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) default NULL,
  coord_system_id int(10) default NULL,
  length int(10) default NULL,
  PRIMARY KEY  (seq_region_id),
  UNIQUE KEY coord_system_id (coord_system_id,name)
) TYPE=MyISAM;
