# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'meta'
#

DROP TABLE IF EXISTS meta;
CREATE TABLE meta (
  meta_id int(11) NOT NULL auto_increment,
  meta_key varchar(40) NOT NULL default '',
  meta_value varchar(255) NOT NULL default '',
  PRIMARY KEY  (meta_id),
  KEY meta_key_index (meta_key),
  KEY meta_value_index (meta_value)
) TYPE=MyISAM;
