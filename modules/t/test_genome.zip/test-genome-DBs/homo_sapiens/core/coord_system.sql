# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'coord_system'
#

CREATE TABLE coord_system (
  coord_system_id int(11) NOT NULL auto_increment,
  name varchar(40) default NULL,
  version varchar(40) default NULL,
  attrib set('default_version','sequence_level') default NULL,
  rank int(11) NOT NULL default '0',
  PRIMARY KEY  (coord_system_id),
  UNIQUE KEY rank (rank),
  UNIQUE KEY name (name,version)
) TYPE=MyISAM;
