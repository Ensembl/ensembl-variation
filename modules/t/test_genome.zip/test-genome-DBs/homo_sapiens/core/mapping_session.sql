# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'mapping_session'
#

DROP TABLE IF EXISTS mapping_session;
CREATE TABLE mapping_session (
  mapping_session_id int(11) NOT NULL auto_increment,
  old_db_name varchar(80) NOT NULL default '',
  new_db_name varchar(80) NOT NULL default '',
  created timestamp(14) NOT NULL,
  PRIMARY KEY  (mapping_session_id)
) TYPE=MyISAM;
