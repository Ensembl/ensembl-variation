# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'misc_feature'
#

CREATE TABLE misc_feature (
  misc_feature_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_end int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_strand tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (misc_feature_id),
  KEY seq_region_idx (seq_region_id,seq_region_start)
);
