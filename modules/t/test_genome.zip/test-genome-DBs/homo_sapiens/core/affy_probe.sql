# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_30
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'affy_probe'
#

CREATE TABLE affy_probe (
  affy_probe_id int(11) NOT NULL auto_increment,
  affy_array_id int(11) NOT NULL default '0',
  probeset varchar(40) collate latin1_bin default NULL,
  name varchar(20) collate latin1_bin default NULL,
  PRIMARY KEY  (affy_probe_id,affy_array_id),
  KEY probeset_idx (probeset),
  KEY array_idx (affy_array_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
