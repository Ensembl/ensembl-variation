# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'affy_probe'
#

CREATE TABLE affy_probe (
  affy_probe_id int(11) NOT NULL auto_increment,
  affy_array_id int(11) NOT NULL default '0',
  probeset varchar(20) default NULL,
  name varchar(20) default NULL,
  PRIMARY KEY  (affy_probe_id,affy_array_id),
  KEY probeset_idx (probeset),
  KEY array_idx (affy_array_id)
) TYPE=MyISAM;
