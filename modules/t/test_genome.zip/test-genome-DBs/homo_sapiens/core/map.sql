# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'map'
#

CREATE TABLE map (
  map_id int(10) unsigned NOT NULL auto_increment,
  map_name varchar(30) NOT NULL default '',
  PRIMARY KEY  (map_id)
) TYPE=MyISAM;
