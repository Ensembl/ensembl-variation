# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'identity_xref'
#

CREATE TABLE identity_xref (
  object_xref_id int(10) unsigned NOT NULL default '0',
  query_identity int(5) default NULL,
  target_identity int(5) default NULL,
  hit_start int(11) default NULL,
  hit_end int(11) default NULL,
  translation_start int(11) default NULL,
  translation_end int(11) default NULL,
  cigar_line text,
  score double default NULL,
  evalue double default NULL,
  analysis_id int(11) default NULL,
  PRIMARY KEY  (object_xref_id)
) TYPE=MyISAM;
