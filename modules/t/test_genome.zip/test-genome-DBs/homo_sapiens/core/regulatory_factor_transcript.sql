CREATE TABLE regulatory_factor_transcript (
  transcript_id int(11) NOT NULL default '0',
  regulatory_factor_id int(11) NOT NULL default '0',
  KEY translation_idx (transcript_id),
  KEY regulatory_factor_idx (regulatory_factor_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
