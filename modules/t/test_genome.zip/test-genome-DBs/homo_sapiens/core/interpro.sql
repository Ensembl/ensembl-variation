# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'interpro'
#

DROP TABLE IF EXISTS interpro;
CREATE TABLE interpro (
  interpro_ac varchar(40) NOT NULL default '',
  id varchar(40) NOT NULL default '',
  KEY interpro_ac (interpro_ac),
  KEY id (id)
) TYPE=MyISAM;
