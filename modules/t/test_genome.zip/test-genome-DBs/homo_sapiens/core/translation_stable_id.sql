# MySQL dump 8.16
#
# Host: ecs2    Database: dr2_test_core
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'translation_stable_id'
#

CREATE TABLE translation_stable_id (
  translation_id int(10) unsigned NOT NULL default '0',
  stable_id varchar(40) NOT NULL default '',
  version int(10) default NULL,
  PRIMARY KEY  (translation_id),
  UNIQUE KEY stable_id (stable_id,version)
) TYPE=MyISAM;
